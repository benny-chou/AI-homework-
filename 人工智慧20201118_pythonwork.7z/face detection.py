
# coding: utf-8

# In[2]:


import cv2
cv2.__version__


# In[4]:


img=cv2.imread('test.jpg')
cv2.imshow('test',img)
cv2.waitKey(0)
cv2.destroyAllWindows()

